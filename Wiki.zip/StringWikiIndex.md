# Wiki of String

- 介绍
	此类是一个自定义的字符串类有许多的函数可使用，其为BasicString类模板，此类最低可支持C++11，开发版本为C++17
	
	声明:  
	`template <typename T, typename SIZE_TYPE = size_t> class BasicString`  
	T为内部存储字符的类型，SIZE_TYPE为计算大小的类型(默认size_t)，T必须为char、wchar_t、char32_t、char16_t的其中之一，SIZE_TYPE必须是比char大的无符号整数类型(也就是至少是short)
	
	若定义USER_NAMESPACE宏那么此类所有东西都会在命名空间里，命名空间名字为USER_NAMESPACE宏的值
- 内容:
	- [成员类型](String成员类型.md)
	- [构造函数](String构造.md)
	- [成员函数](String成员函数.md) <!-- 未完成 -->
	- 辅助别名:
		1. String => `BasicString<char>`
		2. WString => `BasicString<wchar_t>`
		3. Char32String => `BasicString<char32_t>`
		4. Char16String => `BasicString<char16_t>`
		5. WCharString => `WString`
	- 成员变量
		1. sizeType length 字符个数
		2. sizeType capacity 目前容量(自动扩容)
		3. constIterator data 内部数据指针(末尾无\\0占位字符)
		这三个变量在外部都不可修改