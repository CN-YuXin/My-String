# 构造([Return Index](StringWikiIndex.md))

1. `BasicString() noexcept` 默认构造，初始容量15长度0
2. `explicit BasicString(sizeType Cap) noexcept` 初始化容量为Cap，长度为0
3. `template <sizeType SIZE> BasicString(TYPE<const T[SIZE]> &text) noexcept` 初始化为一个字符串字面量，初始容量和长度均为SIZE - 1
4. `BasicString(BasicString&& move) noexcept`  移动构造
5. `BasicString(const BasicString& copy) noexcept` 拷贝构造，初始容量和长度均为copy的长度
6. `template <sizeType SIZE> BasicString(const volatile T(&rarr)[SIZE], sizeType begin, sizeType end) noexcept` 初始化为一个字符数组的部分元素，元素部分为begin~end下标的元素(不包括e)，若begin和end的范围非法那么长度初始化为0容量初始化为SIZE，否则长度和容量都初始化为end begin之差
7. `BasicString(const BasicString& txt, sizeType b, sizeType e) noexcept` 同6
8. `BasicString(std::initializer_list<T> init) noexcept` 使用初始化列表初始化，长度和容量均为init.size()
9. `BasicString(const std::basic_string<T> &stxt) noexcept` 初始化为对应的标准库的String，长度和容量均初始化为stxt.length()
10. `BasicString(sizeType _co, T _c) noexcept` 初始化为\_co个\_c，长度和容量均初始化为_co
11. `BasicString(sizeType _co, const BasicString &_tx) noexcept` 类似于10，初始化为\_co个\_tx，容量和长度均初始化为\_co \* \_tx.length