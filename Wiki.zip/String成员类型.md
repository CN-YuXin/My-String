# 成员类型([Return Index](StringWikiIndex.md))
1. sizeType => `SIZE_TYPE`
2. charType => `T`
3. iterator => `T*`
4. constIterator => `const T*`
5. reverseIterator => `ReverseIterator<iterator>`
6. constReverseIterator => `const reverseIterator`
	ReverseIterator就不多说了(感觉已经可以见名知意了)